package dev.itemdrop;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class Config {
    public static boolean enabled = true;
    public static int speed = 3; // 1..5

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("itemdrop.properties");
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        try (InputStream in = Files.newInputStream(f)) {
            Properties p = new Properties();
            p.load(in);
            enabled = Boolean.parseBoolean(p.getProperty("enabled", "true"));
            speed = Math.max(1, Math.min(5, Integer.parseInt(p.getProperty("speed", "3"))));
        } catch (IOException | NumberFormatException ignored) {
        }
    }

    public static void save() {
        try (OutputStream out = Files.newOutputStream(file())) {
            Properties p = new Properties();
            p.setProperty("enabled", String.valueOf(enabled));
            p.setProperty("speed", String.valueOf(speed));
            p.store(out, "Item Drop");
        } catch (IOException ignored) {
        }
    }

    private Config() {}
}
