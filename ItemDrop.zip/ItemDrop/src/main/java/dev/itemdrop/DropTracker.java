package dev.itemdrop;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Sadece bir oyuncu oldugunde (sen ya da baska biri) o olumden dusen itemlari takip eder.
 * Zaten yerde duran / olumle ilgisi olmayan itemlar hic gosterilmez.
 */
public final class DropTracker {

    public static final class Path {
        public final List<Vec3d> points = new ArrayList<>();
        public int rgb;
    }

    private record Death(Vec3d pos, long tick) {}

    private static final int MAX_STEPS = 240;
    private static final int MAX_PATHS = 64;
    private static final int DEATH_MEMORY_TICKS = 60;
    private static final int CLASSIFY_WINDOW_TICKS = 6;
    private static final double DEATH_RADIUS_SQ = 6.0 * 6.0;

    public static final List<Path> paths = new ArrayList<>();

    private static final List<Death> deaths = new ArrayList<>();
    private static final Set<Integer> deadSeen = new HashSet<>();
    private static final Map<Integer, Long> itemFirstSeen = new HashMap<>();
    private static final Set<Integer> tracked = new HashSet<>();
    private static long tickCount;

    public static void tick(MinecraftClient mc) {
        paths.clear();

        if (mc.world == null || mc.player == null) {
            deaths.clear();
            deadSeen.clear();
            itemFirstSeen.clear();
            tracked.clear();
            return;
        }
        if (!Config.enabled) return;

        tickCount++;

        // 1) Olen oyunculari kaydet
        Set<Integer> deadNow = new HashSet<>();
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof PlayerEntity p && p.isDead()) {
                deadNow.add(p.getId());
                if (deadSeen.add(p.getId())) {
                    deaths.add(new Death(p.getPos(), tickCount));
                }
            }
        }
        deadSeen.retainAll(deadNow);
        deaths.removeIf(d -> tickCount - d.tick > DEATH_MEMORY_TICKS);

        // 2) Itemlari sinifla ve yollarini hesapla
        Set<Integer> present = new HashSet<>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof ItemEntity item)) continue;
            int id = item.getId();
            present.add(id);

            long first = itemFirstSeen.computeIfAbsent(id, k -> tickCount);
            if (!tracked.contains(id) && tickCount - first <= CLASSIFY_WINDOW_TICKS) {
                for (Death d : deaths) {
                    if (d.pos().squaredDistanceTo(item.getPos()) < DEATH_RADIUS_SQ) {
                        tracked.add(id);
                        break;
                    }
                }
            }

            if (tracked.contains(id) && !item.isOnGround() && paths.size() < MAX_PATHS) {
                Path p = simulate(mc, item);
                if (p.points.size() > 1) paths.add(p);
            }
        }
        itemFirstSeen.keySet().retainAll(present);
        tracked.retainAll(present);
    }

    /** ItemEntity.tick() ile ayni sira: yercekimi -> hareket -> surtunme. */
    private static Path simulate(MinecraftClient mc, ItemEntity item) {
        Path path = new Path();
        path.rgb = MathHelper.hsvToRgb((item.getId() * 0.137f) % 1f, 0.75f, 1f);

        Vec3d pos = item.getPos();
        Vec3d vel = item.getVelocity();
        path.points.add(pos);

        for (int i = 0; i < MAX_STEPS; i++) {
            if (!item.hasNoGravity()) vel = vel.add(0, -0.04, 0);

            Vec3d next = pos.add(vel);
            var hit = mc.world.raycast(new RaycastContext(
                    pos, next,
                    RaycastContext.ShapeType.COLLIDER,
                    RaycastContext.FluidHandling.NONE,
                    item));

            if (hit.getType() != HitResult.Type.MISS) {
                path.points.add(hit.getPos());
                break;
            }

            pos = next;
            path.points.add(pos);
            vel = vel.multiply(0.98, 0.98, 0.98);

            if (pos.y < mc.world.getBottomY()) break;
        }
        return path;
    }

    private DropTracker() {}
}
