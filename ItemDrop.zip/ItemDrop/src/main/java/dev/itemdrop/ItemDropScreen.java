package dev.itemdrop;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class ItemDropScreen extends Screen {

    public ItemDropScreen() {
        super(Text.literal("Item Drop"));
    }

    private static Text toggleLabel() {
        return Text.literal("Item Drop: " + (Config.enabled ? "ON" : "OFF"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height / 2 - 20;

        addDrawableChild(ButtonWidget.builder(toggleLabel(), b -> {
            Config.enabled = !Config.enabled;
            b.setMessage(toggleLabel());
            Config.save();
        }).dimensions(cx - 100, y, 200, 20).build());

        addDrawableChild(new SpeedSlider(cx - 100, y + 24, 200, 20));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, this.height / 2 - 42, 0xFFFFFFFF);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_G) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void removed() {
        Config.save();
    }

    private static class SpeedSlider extends SliderWidget {
        SpeedSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), (Config.speed - 1) / 4.0);
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal("Speed: " + Config.speed));
        }

        @Override
        protected void applyValue() {
            Config.speed = 1 + (int) Math.round(this.value * 4.0);
            this.value = (Config.speed - 1) / 4.0;
        }
    }
}
